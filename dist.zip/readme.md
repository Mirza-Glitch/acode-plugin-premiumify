
# Premiumify

Premiumify is a plugin that unlocks premium features of any app. With Premiumify, you can enjoy the full potential of your favorite apps without paying extra fees or subscriptions.

## Features

Premiumify can unlock premium features of various apps, such as:

* Ad-free experience
* Unlock all the app themes
* And everything that the Acode app pro version provides!

## Why did i create this ?

Whenever installing a new plugin, And especially i Always work on big projects, so whenever i needed to open a new folder from the storage in Acode app those annoying ads always irritated me. Although ada are to benefit developers of app and plugins, they always show up on the wrong time. I know that f-droid version of Acode app has unlocked these premium features, but that version always seems to be outdated to me. whenever installing a paid plugin, it showes ```iad is not defined``` alert. I also know that an "Adblocker" plugin is already available in Acode, but it is paid at really high price. I wondered how many helpless programmers out there are just getting annoyed like me. So i created this plugin.

If you want to see the code of this plugin, it is available [here](https://github.com/Mirza-Glitch/acode-plugin-premiumify)